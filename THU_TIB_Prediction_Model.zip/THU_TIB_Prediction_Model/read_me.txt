this is the code of our prediction model
environment: python3.6
run command: pythonn main_chengdu.py
the required python packages can be seen in requirement.txt