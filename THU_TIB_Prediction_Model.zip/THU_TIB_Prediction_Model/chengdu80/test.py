from W_TOOLS.file_manage import pickle_load_file
import pandas as pd
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
from global_v import *
ticker_df = pd.read_csv(DATASET_DIR + 'ticker.tsv',sep=SEP)
ticker_dict = dict(zip(ticker_df['TICKER_ID'],ticker_df['TICKER']))
transactiona_df = pd.read_csv('/work/wangzhen/HENR/chengdu80/data/dataset/chengdu80_test.tsv',sep='\t')
aaa = pickle_load_file('/work/wangzhen/HENR/result/Stock_predict/202010281622.test.pk')
true_label = transactiona_df['label']
prediction = []
transactiona_df['TICKER'] =  transactiona_df['TICKER'].map(lambda a : ticker_dict[a])
prediction = [1 if item > 0.5 else 0 for item in aaa['result']]
probability = [float(min(0.99,10*abs(item-0.5))) for item in aaa['result']]
print(len(transactiona_df['BIDLO']))
transactiona_df['probability'] = probability
transactiona_df['prediction'] = prediction
print(accuracy_score(list(transactiona_df['prediction']),list(transactiona_df['label'])))
ticker_df.to_csv(DATASET_DIR + 'ticker.tsv',sep=SEP,index=None)
df = pd.DataFrame()
column_list = ['date','TICKER','BIDLO','ASKHI','OPENPRC','PRC','NEXT_DELTA','THIS_DELTA','label','this_day_label','prediction','probability']

for column_item in column_list:
    df[column_item] = transactiona_df[column_item]

df.to_csv('/work/wangzhen/HENR/chengdu80/data/dataset/202010281622.test.predict.csv',sep=',',index=None)
bbbb = 0
# CORRELATION	POLARITY	NEWS_TILE	NEWS_KEYWORDS
news = pd.read_csv('/work/wangzhen/HENR/chengdu80/data/dataset/news/news_KnowledgeGraph.csv')
news.fillna('')
news_dict = {}
news_dict_list = {'date':[],'title':[],'keywords':[],'polarity':[]}
news = news.to_dict('list')
bbbbb = []
# date title keywords polarity
for i in range(len(news['date'])):
    if news['date'][i] not in news_dict:
        news_dict[news['date'][i]] = 0
        for column_item in news_dict_list:
            news_dict_list[column_item].append(news[column_item][i])
        bbbbb = np.random.randint(0,1000)* 1.0/1000
news_dict_list['correlation'] = bbbbb
news_dataframe = pd.DataFrame()
for k in news_dict_list:
    news_dataframe[k] = news_dict_list[k]
transactiona_df_news = pd.merge(transactiona_df, news_dataframe, left_index=True, right_index=True, how='left')
transactiona_df_news.to_csv('/work/wangzhen/HENR/chengdu80/data/dataset/202010281622.test.predict_corre_news.csv',sep=',',index=None)
industry = pd.read_csv('/work/wangzhen/HENR/chengdu80/data/dataset/industrial_relation.tsv',sep='\t')
stick_industry = dict(zip(industry['Ticker'],zip(industry['CRSC Industry'])))
stick_industry['CELG'] = 'Manufacture'
transactiona_df_news['industry'] = transactiona_df_news['TICKER'].map(lambda a : stick_industry[a] if a in stick_industry.keys() else 'Manufacture')
transactiona_df_news['prediction'] = transactiona_df_news['prediction'].shift(1)
transactiona_df_news.dropna(subset=['label'],inplace=True)
transactiona_df_news.dropna(subset=['prediction','THIS_DELTA'],inplace=True)
transactiona_df_news['delta'] = transactiona_df_news['prediction'] * transactiona_df_news['THIS_DELTA']
gbd = transactiona_df_news.groupby('date_x')
date_list = []
industry = []
industry_change = []
for i in gbd:
    ddd = i
    date_item = ddd[0]
    date_item_list = []
    industry_list = []
    industry_win = []
    industry_group = ddd[1].groupby('industry')
    for industry_name,STICKER_LIST in industry_group:
        date_item_list.append(date_item)
        industry_list.append(str(industry_name[0]))
        industry_win.append(sum(STICKER_LIST['delta']))
    abs_list = [abs(abs_item) for abs_item in industry_win]
    abs_sum = sum(abs_list)
    industry_win = [win_item/abs_sum for win_item in industry_win]
    date_list.extend(date_item_list)
    industry.extend(industry_list)
    industry_change.extend(industry_win)
industry_df = pd.DataFrame()
industry_df['date'] = date_list
industry_df['industry'] = industry
industry_df['percent'] = industry_change
industry_df.to_csv('/work/wangzhen/HENR/chengdu80/data/dataset/202010281622.test.industry_importance_distribution.csv',sep=',',index=None)
aa = 1