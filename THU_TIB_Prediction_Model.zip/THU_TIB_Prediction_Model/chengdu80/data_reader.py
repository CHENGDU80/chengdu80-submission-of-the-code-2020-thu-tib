import numpy as np
import pandas as pd
import os
from global_v import *
from collections import Counter, defaultdict
import tqdm

class data_reader(object):
    @staticmethod
    def parse_data_args(parser):
        parser.add_argument('--path',type=str,default=DATASET_DIR,help='Input data dir')
        parser.add_argument('--dataset',type=str,default='chengdu80',help='Choose a dataset')
        parser.add_argument('--sep',type=str,default='\t',help='sep of csv file')
        parser.add_argument('--label',type=str,default=LABEL)
        parser.add_argument('--window', type=int, default=20)
        return parser

    def __init__(self,path,dataset,sep,label,window):
        self.dataset = dataset
        self.path = path
        self.train_file = os.path.join(self.path,dataset + TRAIN_SUFFIX)
        self.validation_file = os.path.join(self.path,dataset + VALIDATION_SUFFIX)
        self.test_file = os.path.join(self.path,dataset + TEST_SUFFIX)
        self.label = label
        self.window = window
        self.info = {}
        self.ticker_history = defaultdict(list)
        self.load_data()

    def get_process_data(self,df):
        # ticker , ticker list
        column_list = ['OPENPRC_NORM', 'BIDLO_NORM', 'ASKHI_NORM', 'PRC_NORM','this_day_label']
        def padding_history(this_history):
            padding = []
            if len(this_history) < self.window:
                for i in range(self.window - len(this_history)):
                    padding.append([0.0 for column_item in column_list])
            padding.extend(this_history)
            return padding

        df['history'] = dict()
        for index in tqdm.tqdm(df['TICKER']):
            item_list = []
            for column_item in column_list:
                item_list.append(df[column_item][index])
            self.ticker_history[df['TICKER'][index]].append(item_list)
            total_history = self.ticker_history[df['TICKER'][index]]
            this_len = len(total_history)
            this_history = padding_history(total_history[max(0,this_len-self.window):])
            df['history'][index] = this_history

    def get_individual_file(self,file):
        df = pd.read_csv(file,sep='\t')
        df = df.to_dict(orient='dict')
        # return {'history': [self.df['OPENPRC'][index],self.df['BIDLO'][index],
        #  self.df['ASKHI'][index],self.df['PRC'][index],self.df['PRC'][index] - self.df['OPENPRC'][index]],
        #  'label':self.df['label'][index]}
        self.get_process_data(df)
        return df

    def load_data(self):
        self.train_df = self.get_individual_file(self.train_file)
        self.validation_df = self.get_individual_file(self.validation_file)
        self.test_df = self.get_individual_file(self.test_file)
        # column_list = ['OPENPRC_NORM', 'BIDLO_NORM', 'ASKHI_NORM', 'PRC_NORM']
