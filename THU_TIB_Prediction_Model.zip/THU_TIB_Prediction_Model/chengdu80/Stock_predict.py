import torch
from utils import utils, components
import torch.nn as nn
import numpy as np
from utils.rank_metrics import *
from sklearn.metrics import *
import os
import logging

class Stock_predict(torch.nn.Module):
    @staticmethod
    def parse_model_args(parser):
        parser.add_argument('--hidden_size', type=int, default=128,
                            help='Size of hidden vectors in GRU.')
        parser.add_argument('--num_layers', type=int, default=1,
                            help='Number of GRU layers.')

        parser.add_argument('--p_layers', type=str, default='[64]',
                        help="Size of each layer.")
        return parser

    def __init__(self,hidden_size,num_layers,p_layers,args_dict,model_path,*args, **kwargs):
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.p_layers = p_layers if type(p_layers) == list else eval(p_layers)
        self.args_dict = args_dict
        self.optimizer = None
        self.model_path = model_path
        torch.nn.Module.__init__(self)
        self._init_weights()

    def init_paras(self, m):
        """
        模型自定义初始化函数，在main.py中会被调用
        :param m: 参数或含参数的层
        :return:
        """
        if 'Linear' in str(type(m)):
            torch.nn.init.normal_(m.weight, mean=0.0, std=0.01)
            if m.bias is not None:
                torch.nn.init.normal_(m.bias, mean=0.0, std=0.01)
        elif 'Embedding' in str(type(m)):
            torch.nn.init.normal_(m.weight, mean=0.0, std=0.01)

    def _init_weights(self):
        self.l2_embeddings = ['uid_embeddings', 'word_embeddings']
        self.iid_embeddings = torch.nn.Embedding(500, 64)
        self.rnn = torch.nn.GRU(
            input_size=5, hidden_size=128, batch_first=True,
            num_layers=self.num_layers)
        self.out = torch.nn.Linear(self.hidden_size, 128, bias=False)
        self.out2 = torch.nn.Linear(128,64, bias=True)
        self.out3 = torch.nn.Linear(64, 1, bias=True)

    def predict(self, feed_dict):
        history = feed_dict['history']
        valid = torch.sum(history,dim=-1).gt(0).float()
        output, hidden = components.seq_rnn(history, valid=valid, rnn=self.rnn, lstm=False)
        rnn_vector = output[:,-1,:].squeeze(dim=-2)
        rnn_vector = self.out(rnn_vector)
        rnn_vector2 = self.out2(rnn_vector)
        output = self.out3(rnn_vector2)
        out_dict = {'result': output}
        return out_dict
    def forward(self, feed_dict):
        """
        除了预测之外，还计算loss
        :param feed_dict: 型输入，是个dict
        :return: 输出，是个dict，prediction是预测值，check是需要检查的中间结果，loss是损失
        """
        out_dict = self.predict(feed_dict)
        label = feed_dict['label'].float().flatten().unsqueeze(dim=-1)

        loss = torch.sqrt(nn.MSELoss()(out_dict['result'],label))
        out_dict['loss'] = loss
        out_dict['loss_l2'] = self.l2(out_dict)
        return out_dict
    @staticmethod
    def evaluate_method(p, data, metrics, error_skip=False):
        """
        计算模型评价指标
        :param p: 预测值，np.array，一般由runner.predict产生
        :param data: data dict，一般由DataProcessor产生
        :param metrics: 评价指标的list，一般是runner.metrics，例如 ['rmse', 'auc']
        :return:
        """
        p = p['result'].reshape([-1])
        l = data.get_column('label').reshape([-1])
        evaluations = []
        rank = False
        for metric in metrics:
            if '@' in metric:
                rank = True

        split_l, split_p, split_l_sum = None, None, None
        if rank:
            uids = data.get_column(UID).reshape([-1])
            times = data.get_column(TIME).reshape([-1]) if TIME in data.get_column_names() else None
            if len(l) != len(p):
                uids = np.concatenate([uids] * (len(p) // len(l)))
                times = np.concatenate([times] * (len(p) // len(l))) if times is not None else None
                l = np.concatenate([l, np.zeros(len(p) - len(l))])

            # fix nan in p
            p_nan, l_pos = np.isnan(p), l > 0
            p_max, p_min = np.nan_to_num(np.nanmax(p), nan=1.0), np.nan_to_num(np.nanmin(p), nan=-1.0)
            p[p_nan & l_pos], p[p_nan & ~l_pos] = p_min, p_max

            sorted_idx = np.lexsort((-l, -p, times, uids))
            sorted_uid, sorted_time = uids[sorted_idx], times[sorted_idx]
            sorted_key, sorted_spl = np.unique([sorted_uid, sorted_time], axis=1, return_index=True)
            sorted_l, sorted_p = l[sorted_idx], p[sorted_idx]
            split_l, split_p = np.split(sorted_l, sorted_spl[1:]), np.split(sorted_p, sorted_spl[1:])
            split_l_sum = [np.sum((d > 0).astype(float)) for d in split_l]

        for metric in metrics:
            try:
                if metric == 'rmse':
                    evaluations.append(np.sqrt(mean_squared_error(l, p)))
                elif metric == 'mae':
                    evaluations.append(mean_absolute_error(l, p))
                elif metric == 'auc':
                    evaluations.append(roc_auc_score(l, p))
                elif metric == 'f1':
                    evaluations.append(f1_score(l, np.around(p)))
                elif metric == 'accuracy':
                    evaluations.append(accuracy_score(l, np.around(p)))
                elif metric == 'precision':
                    evaluations.append(precision_score(l, np.around(p)))
                elif metric == 'recall':
                    evaluations.append(recall_score(l, np.around(p)))
                else:
                    k = int(metric.split('@')[-1])
                    if metric.startswith('ndcg@'):
                        max_k = max([len(d) for d in split_l])
                        k_data = np.array([(list(d) + [0] * max_k)[:max_k] for d in split_l])
                        best_rank = -np.sort(-k_data, axis=1)
                        best_dcg = np.sum(best_rank[:, :k] / np.log2(np.arange(2, k + 2)), axis=1)
                        best_dcg[best_dcg == 0] = 1
                        dcg = np.sum(k_data[:, :k] / np.log2(np.arange(2, k + 2)), axis=1)
                        ndcgs = dcg / best_dcg
                        evaluations.append(np.average(ndcgs))

                        # k_data = np.array([(list(d) + [0] * k)[:k] for d in split_l])
                        # best_rank = -np.sort(-k_data, axis=1)
                        # best_dcg = np.sum(best_rank / np.log2(np.arange(2, k + 2)), axis=1)
                        # best_dcg[best_dcg == 0] = 1
                        # dcg = np.sum(k_data / np.log2(np.arange(2, k + 2)), axis=1)
                        # ndcgs = dcg / best_dcg
                        # evaluations.append(np.average(ndcgs))
                    elif metric.startswith('hit@'):
                        k_data = np.array([(list(d) + [0] * k)[:k] for d in split_l])
                        hits = (np.sum((k_data > 0).astype(float), axis=1) > 0).astype(float)
                        evaluations.append(np.average(hits))
                    elif metric.startswith('precision@'):
                        k_data = [d[:k] for d in split_l]
                        k_data_dict = defaultdict(list)
                        for d in k_data:
                            k_data_dict[len(d)].append(d)
                        precisions = [np.average((np.array(d) > 0).astype(float), axis=1) for d in k_data_dict.values()]
                        evaluations.append(np.average(np.concatenate(precisions)))
                    elif metric.startswith('recall@'):
                        k_data = np.array([(list(d) + [0] * k)[:k] for d in split_l])
                        recalls = np.sum((k_data > 0).astype(float), axis=1) / split_l_sum
                        evaluations.append(np.average(recalls))
            except Exception as e:
                if error_skip:
                    evaluations.append(-1)
                else:
                    raise e
        return evaluations
    def l2(self, out_dict):
        """
        模型l2计算，默认是所有参数（除了embedding之外）的平方和，
        Embedding 的 L2是 只计算当前batch用到的
        :return:
        """
        l2 = utils.numpy_to_torch(np.array(0.0, dtype=np.float32), gpu=True)
        for name, p in self.named_parameters():
            if not p.requires_grad:
                continue
            if name.split('.')[0] in self.l2_embeddings:
                continue
            l2 += (p ** 2).sum()
        return l2

    def save_model(self, model_path=None):
        """
        保存模型，一般使用默认路径
        :param model_path: 指定模型保存路径
        :return:
        """
        if model_path is None:
            model_path = self.model_path
        dir_path = os.path.dirname(model_path)
        if not os.path.exists(dir_path):
            os.mkdir(dir_path)
        torch.save(self.state_dict(), model_path)
        logging.info('Save model to ' + model_path)

    def load_model(self, model_path=None, cpu=False):
        """
        载入模型，一般使用默认路径
        :param model_path: 指定模型载入路径
        :return:
        """
        if model_path is None:
            model_path = self.model_path
        if cpu:
            self.load_state_dict(torch.load(model_path, map_location=lambda storage, loc: storage))
        else:
            self.load_state_dict(torch.load(model_path))
        self.eval()
        logging.info('Load model from ' + model_path)
