
1. the transaction_data.tsv (seperated by "\t") file contains all the transcation data of the active stocks during 2012.
"date": transaction_date, "TICKER": stock ticker, "COMNAM": company name, "BIOLO": lowest price, "ASKHI": highest price, "OPENPRC": opening price, "PRC": closing price, "VOL": trading volume, "SHROUT": shares outstanding.
    
2. The 2012_finnancial_news contains all the news collected news during 2012. All the news are unpreprocessed.

3. The industrial_relatoin.tsv (seperated by "\t") file tells the which industry listed firms belong to. Participants are encourage to collect other firm relation information from the internet.


