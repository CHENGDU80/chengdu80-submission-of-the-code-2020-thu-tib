import pandas as pd
from global_v import *
from sklearn.utils import shuffle

#read the raw file
transanction =  pd.read_csv(DATASET_DIR + 'transaction_data.tsv', sep = '\t')
TICKER = list(transanction['TICKER'].unique())
ticker_dict = dict(zip(TICKER,list(range(1,1+len(TICKER)))))

ticker_df = pd.DataFrame()
ticker_df['TICKER'] = TICKER

ticker_df['TICKER_ID'] = list(range(1,1+len(TICKER)))
ticker_df.to_csv(DATASET_DIR + 'ticker.tsv',sep=SEP,index=None)

del transanction['COMNAM']

transanction['NEXT_DAY_PRC'] = transanction.groupby('TICKER')['PRC'].shift(-1)
transanction['LAST_DAY_PRC'] = transanction.groupby('TICKER')['PRC'].shift(1)
# return {'history': [self.df['OPENPRC'][index], self.df['BIDLO'][index],
#                     self.df['ASKHI'][index], self.df['PRC'][index], self.df['PRC'][index] - self.df['OPENPRC'][index]],
#         'label': self.df['label'][index]}
column_list = ['OPENPRC','BIDLO','ASKHI','PRC']
for column_item in column_list:
    transanction.dropna(subset=[column_item],inplace=True)
def get_max(column_name):
    aaaa = transanction.groupby('TICKER')[column_name].max() + 0.1
    bbbb = aaaa.to_dict()
    transanction[column_name + '_MAX'] = transanction['TICKER'].map(lambda a: bbbb[a])
    transanction[column_name + '_NORM'] = transanction[column_name] / transanction[column_name+ '_MAX']
    return
for column_item in column_list:
    get_max(column_item)

transanction['BIDLO_MAX'] = transanction.groupby('TICKER')['BIDLO'].max() + 0.1
transanction['ASKHI_MAX'+ '_MAX'] = transanction.groupby('TICKER')['ASKHI'].max() + 0.1
transanction['PRC_MAX'] = transanction.groupby('TICKER')['PRC'].max() + 0.1
transanction.dropna(subset=['NEXT_DAY_PRC'],inplace=True)
transanction.dropna(subset=['LAST_DAY_PRC'],inplace=True)
transanction['NEXT_DELTA'] = transanction['NEXT_DAY_PRC'] - transanction['PRC']
transanction['THIS_DELTA'] = transanction['PRC'] - transanction['LAST_DAY_PRC']
transanction['label'] = transanction['NEXT_DELTA'].map(lambda a: 1 if a>0 else 0)
transanction['this_day_label'] = transanction['THIS_DELTA'].map(lambda a: 1 if a>0 else 0)
transanction['TICKER'] =  transanction['TICKER'].map(lambda a : ticker_dict[a])
transanction.to_csv(DATASET_DIR + 'transanction_new.tsv',sep=SEP,index=None)
# split train validation test
transanction.fillna(50.0)
transanction = transanction.sort_values(by=['date','TICKER'],ascending=True)
train = transanction[:int(len(transanction) * 0.8)].sort_values(by=['TICKER','date'],ascending=True)
valid = transanction[int(len(transanction) * 0.8):int(len(transanction) * 0.9)].sort_values(by=['TICKER','date'],ascending=True)
test = transanction[:].sort_values(by=['TICKER','date'],ascending=True)
train.to_csv(DATASET_DIR + 'chengdu80_train.tsv',sep=SEP,index=None)
valid.to_csv(DATASET_DIR + 'chengdu80_valid.tsv',sep=SEP,index=None)
test.to_csv(DATASET_DIR + 'chengdu80_test.tsv',sep=SEP,index=None)