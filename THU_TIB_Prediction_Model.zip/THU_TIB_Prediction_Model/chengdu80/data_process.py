# coding=utf-8
import copy
from utils import utils
import numpy as np
import logging
import pandas as pd
from tqdm import tqdm
import torch
from collections import defaultdict
from torch.utils.data import Dataset

class data_process(Dataset):

    @staticmethod
    def parse_dp_args(parser):
        """
        数据处理生成batch的命令行参数
        :param parser:
        :return:
        """
        parser.add_argument('--sparse_his', type=int, default=0,
                            help='Whether use sparse representation of user history.')
        parser.add_argument('--test_sample_n', type=int, default=100,
                            help='Negative sample num for each instance in test/validation set when ranking.')
        parser.add_argument('--train_sample_n', type=int, default=1,
                            help='Negative sample num for each instance in train set when ranking.')
        parser.add_argument('--sample_un_p', type=float, default=1.0,
                            help='Sample from neg/pos with 1-p or unknown+neg/pos with p.')
        parser.add_argument('--sample_pop', type=int, default=0,
                            help='Whether sample according to popularity')
        parser.add_argument('--sample_given_p', type=float, default=0.5,
                            help='Sample from given neg/pos with 1-p or others with p.')
        parser.add_argument('--buffer_dp', type=int, default=0,
                            help='Whether buffer dp items or not.')
        # parser.add_argument('--buffer_dp_b', type=int, default=1,
        #                     help='Whether buffer dp batches or not for evaluation.')
        return parser

    def __init__(self,df,*args,**kwargs):
        '''
        :param max_his:
        :param sparse_his:
        :param rank:
        :param test_sample_n:
        :param train_sample_n:
        :param sample_un_p:
        :param sample_pop:
        :param sample_given_p:
        :param df:
        :param procedure:
        :param data_reader:
        :param model_name:
        :param negtive_type: negtive sample source, 0 mean whole dataset, 1 mean test dataset,
        :param batch_size:
        :param eval_batch_size:
        :param args:
        :param kwargs:
        '''
        self.df = df

    def __getitem__(self, index):
        # column_list = ['OPENPRC_NORM', 'BIDLO_NORM', 'ASKHI_NORM', 'PRC_NORM']
        return {'history': self.df['history'][index],
         'label':self.df['label'][index]}

    def __len__(self):
        for k in self.df:
            return len(self.df[k])
    def collect_batch(self, batch):
        return self.get_batch(batch)

    def get_batch(self, batch, skip_keys=None, info_keys=None):
        batch = batch
        batch_dict = {'history':[],
                      'label':[]}
        for item in batch:
            batch_dict['history'].append(item['history'])
            batch_dict['label'].append([item['label']])
        # a[np.isnan(a)] = 0
        batch_dict['history'] = torch.from_numpy(np.array(batch_dict['history'])).float()
        batch_dict['label'] = torch.from_numpy(np.array(batch_dict['label'])).float()
        batch_dict['history'][np.isnan(batch_dict['history'])] = 30
        batch_dict['label'][np.isnan(batch_dict['label'])] = 30
        return batch_dict
    def batch_to_gpu(self, batch):
        if torch.cuda.device_count() > 0:
            new_batch = {}
            for c in batch:
                if type(batch[c]) is torch.Tensor:
                    new_batch[c] = batch[c].cuda()
                else:
                    new_batch[c] = batch[c]
            return new_batch
        return batch

    def get_column(self, column):
        return np.array(list(self.df[column].values()))